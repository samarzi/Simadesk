/**
 * Ozon Seller — автоматизация настройки зон складов.
 * Порт ozon_warehouse.py на JavaScript для Chrome Extension.
 *
 * Структура страницы:
 *   Карточки складов: li внутри ul
 *   Название: [data-widget="warehouse-card-title"]
 *   Зоны: div.nd4-ea6[title="..."]
 *   Карандаш: button[title="Редактировать метод"]
 *   Далее: button:has-text("Далее")
 *   Сохранить: button:has-text("Сохранить")
 *   Поиск: input[placeholder="Направление доставки"]
 *   Чекбокс: input[type="checkbox"] в строке таблицы
 */
(() => {
  'use strict';
  // Двойная защита: window (текущий контекст) + sessionStorage (между инъекциями)
  if (window.__SD_OZ_WH_RUNNING) return;
  if (sessionStorage.getItem('__sd_wh_running') === '1') return;
  window.__SD_OZ_WH_RUNNING = true;
  sessionStorage.setItem('__sd_wh_running', '1');
  // Очищаем флаг при выгрузке страницы
  window.addEventListener('beforeunload', () => sessionStorage.removeItem('__sd_wh_running'));

  // ── Константы ───────────────────────────────────────────────────────────
  const SEARCH_DEBOUNCE_MS = 800;
  const AFTER_SAVE_MS = 3000;

  // ── Утилиты ─────────────────────────────────────────────────────────────

  let stopped = false;
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  function log(text) {
    const ts = new Date().toLocaleTimeString('ru-RU');
    const line = `[${ts}] ${text}`;
    console.log('[SimaDesk:OzWH]', line);
    window.dispatchEvent(new CustomEvent('sd-log', { detail: { text: line } }));
  }

  function setStatus(status, detail) {
    window.dispatchEvent(new CustomEvent('sd-status', { detail: { status, detail } }));
  }

  function sendProgress(done, total, label) {
    window.dispatchEvent(new CustomEvent('sd-progress', { detail: { done, total, label } }));
  }

  function checkStop() {
    if (window.__SD_STOP || stopped) { stopped = true; throw new Error('STOPPED'); }
  }

  function normalize(text) {
    if (!text) return '';
    let t = text.toLowerCase().trim();
    t = t.replace(/ё/g, 'е');
    t = t.replace(/\bг\.?\s*/g, '');
    t = t.replace(/\s+/g, ' ').trim();
    return t;
  }

  // ── Проверка авторизации ────────────────────────────────────────────────

  async function checkAuth(timeout = 25000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const cards = document.querySelectorAll('[data-widget="warehouse-card-title"]');
      if (cards.length > 0) return true;
      if (window.location.href.includes('login') || window.location.href.includes('passport')) {
        return false;
      }
      await sleep(1000);
    }
    return false;
  }

  // ── Прокрутка страницы для подгрузки всех складов (lazy loading) ────────

  async function scrollToLoadAllWarehouses() {
    // Активируем вкладку: без этого IntersectionObserver не срабатывает в фоне
    window.dispatchEvent(new CustomEvent('sd-activate-tab'));
    await sleep(600);

    log('→ Прокрутка для подгрузки всех складов...');
    let prevCount = 0;
    let stableRuns = 0;
    for (let attempt = 0; attempt < 40; attempt++) {
      const cards = document.querySelectorAll('[data-widget="warehouse-card-title"]');
      if (cards.length === prevCount) {
        stableRuns++;
        if (stableRuns >= 4) break; // 4 итерации без изменений = все загружены
      } else {
        stableRuns = 0; // новые карточки появились — сбрасываем счётчик
      }
      prevCount = cards.length;
      // Скроллим к последней карточке И до самого низа страницы
      if (cards.length > 0) {
        cards[cards.length - 1].scrollIntoView({ block: 'end', behavior: 'smooth' });
        await sleep(300);
      }
      window.scrollTo(0, document.body.scrollHeight);
      await sleep(1800); // больше времени на lazy-load
    }
    // Возвращаемся наверх, чтобы карточки были видны
    window.scrollTo({ top: 0, behavior: 'smooth' });
    await sleep(800);
    log(`→ Всего складов на странице: ${document.querySelectorAll('[data-widget="warehouse-card-title"]').length}`);
  }

  // ── Сканирование складов ────────────────────────────────────────────────

  function scanWarehouses() {
    const cards = document.querySelectorAll('[data-widget="warehouse-card-title"]');
    const warehouses = [];
    for (let i = 0; i < cards.length; i++) {
      const card = cards[i];
      const name = card.textContent.trim();
      const li = card.closest('li');
      const zones = [];
      const seen = new Set();
      if (li) {
        // NO keyword filter — zone names like "Феникс 2025", "Липецк", "Курьером"
        // must all be captured. Use class-based selector with div[title] fallback.
        const zoneDivs = li.querySelectorAll('.nd4-ea6[title], [class*="ea6"][title], div[title]');
        for (const zd of zoneDivs) {
          const t = zd.getAttribute('title') || '';
          if (t && t.length > 1 && t.length < 100 && !seen.has(t)) {
            seen.add(t);
            zones.push({ name: zd.textContent.trim(), title: t });
          }
        }
      }
      warehouses.push({ name, index: i, zones });
    }
    return warehouses;
  }

  // ── Раскрытие скрытых методов ───────────────────────────────────────────

  async function expandHiddenMethods(warehouseName) {
    const normWName = normZone(warehouseName);
    for (let attempt = 0; attempt < 20; attempt++) {
      const cards = document.querySelectorAll('[data-widget="warehouse-card-title"]');
      let clicked = false;
      for (const card of cards) {
        if (normZone(card.textContent.trim()) !== normWName) continue;
        const li = card.closest('li');
        if (!li) continue;
        card.scrollIntoView({ block: 'center', behavior: 'smooth' });
        await sleep(500);
        const buttons = li.querySelectorAll('button');

        if (attempt === 0) {
          // Диагностика: список всех кнопок в карточке склада
          const btnTexts = [...buttons].map(b => b.textContent.trim()).filter(t => t.length > 0 && t.length < 60);
          log(`[DBG] expand attempt=${attempt}, кнопок в li: ${buttons.length}, тексты: ${JSON.stringify(btnTexts)}`);
        }

        for (const btn of buttons) {
          const text = btn.textContent.trim().toLowerCase();
          if (text.includes('показать ещё') || text.includes('показать еще') || text.includes('show more')) {
            btn.scrollIntoView({ block: 'center' });
            btn.click();
            clicked = true;
            log(`[DBG] expand: кликнуто «${btn.textContent.trim()}»`);
            await sleep(2000);
            break;
          }
        }
        break;
      }
      if (!clicked) {
        if (attempt === 0) log('[DBG] expand: кнопка «показать ещё» не найдена → выход');
        break;
      }
    }
    log('✅ Все методы раскрыты');
  }

  // ── Клик на кнопку редактирования зоны (карандаш) ───────────────────────
  // Карандаш на Ozon появляется только при наведении — шлём mouseover перед поиском.

  // Нормализация для нечёткого сравнения названий зон
  function normZone(s) {
    return (s || '').toLowerCase().replace(/ё/g, 'е').replace(/[.\-–—]/g, ' ').replace(/\s+/g, ' ').trim();
  }

  async function findZoneEditButton(warehouseName, zoneTitle) {
    const normTarget = normZone(zoneTitle);
    const cards = document.querySelectorAll('[data-widget="warehouse-card-title"]');
    log(`[DBG] findZoneEditButton: ищем склад «${warehouseName}», зону «${zoneTitle}»`);
    log(`[DBG] Карточек складов на странице: ${cards.length}`);

    const normWName = normZone(warehouseName);
    for (const card of cards) {
      if (normZone(card.textContent.trim()) !== normWName) continue;
      const li = card.closest('li');
      if (!li) continue;

      // Скроллим вниз внутри карточки чтобы подгрузить скрытые зоны
      const liRect = li.getBoundingClientRect();
      for (let scrollStep = 0; scrollStep < 5; scrollStep++) {
        window.scrollBy(0, liRect.height / 4);
        await sleep(300);
      }
      li.scrollIntoView({ block: 'center', behavior: 'smooth' });
      await sleep(600);

      const zoneDivs = li.querySelectorAll('div[title], .nd4-ea6, [class*="ea6"]');
      log(`[DBG] div[title] внутри склада: ${zoneDivs.length}`);
      const allTitles = [...zoneDivs].map(d => d.getAttribute('title') || d.textContent.trim()).filter(Boolean);
      log(`[DBG] Найденные title: ${JSON.stringify(allTitles.slice(0, 15))}`);

      for (const zd of zoneDivs) {
        const title = zd.getAttribute('title') || zd.textContent.trim();
        // Нечёткое совпадение: игнорируем точки, дефисы, регистр
        if (normZone(title) !== normTarget) continue;

        log(`[DBG] Зона найдена! Скроллим...`);
        zd.scrollIntoView({ block: 'center', behavior: 'smooth' });
        await sleep(600);

        const parent = zd.closest('.nd4-ea5') || zd.closest('.sc8131-a') ||
                       zd.closest('[class*="ea5"]') || zd.closest('[class*="method"]') ||
                       zd.parentElement;
        const searchRoot = parent || li;

        // 1. Точный title
        let editBtn = searchRoot.querySelector('button[title="Редактировать метод"]');
        if (editBtn) {
          log(`[DBG] ✅ Карандаш найден сразу`);
          editBtn.scrollIntoView({ block: 'center' });
          await sleep(200);
          editBtn.click();
          return true;
        }

        // 2. Mouseover — карандаш часто скрыт до наведения
        zd.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
        zd.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
        searchRoot.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
        await sleep(600);

        editBtn = searchRoot.querySelector('button[title="Редактировать метод"]');
        if (editBtn) {
          log(`[DBG] ✅ Карандаш найден после mouseover`);
          editBtn.scrollIntoView({ block: 'center' });
          await sleep(200);
          editBtn.click();
          return true;
        }

        // 3. Кнопка с «Редактировать» в title или тексте
        for (const btn of searchRoot.querySelectorAll('button')) {
          const t = (btn.getAttribute('title') || btn.textContent || '').toLowerCase();
          if (t.includes('редактировать') || t.includes('edit')) {
            log(`[DBG] ✅ Редактировать найден по тексту`);
            btn.scrollIntoView({ block: 'center' });
            await sleep(200);
            btn.click();
            return true;
          }
        }

        // 4. SVG карандаш (path '4.989')
        for (const btn of searchRoot.querySelectorAll('button')) {
          const svg = btn.querySelector('svg');
          if (svg && svg.innerHTML.includes('4.989')) {
            log(`[DBG] ✅ SVG карандаш найден`);
            btn.scrollIntoView({ block: 'center' });
            await sleep(200);
            btn.click();
            return true;
          }
        }

        // Диагностика: что вообще есть в searchRoot
        const allBtns = [...searchRoot.querySelectorAll('button')];
        log(`[DBG] ❌ Карандаш не найден. Кнопок в parent: ${allBtns.length}, titles: ${JSON.stringify(allBtns.map(b => b.getAttribute('title') || b.textContent.trim().slice(0,20)).filter(Boolean))}`);
      }
    }
    log(`[DBG] ❌ Зона «${zoneTitle}» не найдена среди div[title]`);
    return false;
  }

  // ── Навигация по шагам (Далее / Сохранить) ──────────────────────────────

  async function clickButton(text, timeout = 5000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const buttons = [...document.querySelectorAll('button')];
      const btn = buttons.find(b => b.textContent.trim() === text && b.offsetParent !== null);
      if (btn && !btn.disabled) {
        btn.scrollIntoView({ block: 'center' });
        await sleep(300);
        btn.click();
        log(`→ Клик «${text}»`);
        await sleep(1500);
        return true;
      }
      await sleep(500);
    }
    return false;
  }

  // ── Ожидание поля поиска ────────────────────────────────────────────────

  async function waitForSearchPage(timeout = 15000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const input = document.querySelector("input[placeholder='Направление доставки']");
      if (input && input.offsetParent !== null) {
        log('✅ Поле поиска городов готово');
        return true;
      }
      await sleep(500);
    }
    log('❌ Поле поиска не появилось');
    return false;
  }

  // ── Поиск и выбор города ────────────────────────────────────────────────
  //
  // ВАЖНО: не используем Promise.race с внешним sleep-таймером.
  // Причина: в фоновой вкладке Chrome throttle-ит ВСЕ setTimeout одинаково
  // (до 1 с, а при глубоком фоне — до 60 с). При гонке двух throttle-нутых
  // таймеров (sleep(800) внутри и sleep(20000) снаружи) внешний может
  // сработать первым, «убив» поиск до того, как DOM-проверка выполнится.
  //
  // Решение: один начальный yield → сразу проверяем DOM (Ozon уже ответил,
  // даже если спали 60 с вместо 700 мс) → используем Date.now() для реального
  // дедлайна вместо нового sleep-таймера.

  async function _doSearchAndSelect(cityName) {
    const searchInput = document.querySelector("input[placeholder='Направление доставки']");
    if (!searchInput || searchInput.offsetParent === null) return 'failed';

    // Устанавливаем значение через React-совместимый nativeSet.
    // НЕТ sleep между clear и set — один единственный yield в конце.
    searchInput.focus();
    const nativeSet = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    nativeSet.call(searchInput, '');
    searchInput.dispatchEvent(new Event('input', { bubbles: true }));
    nativeSet.call(searchInput, cityName);
    searchInput.dispatchEvent(new Event('input', { bubbles: true }));
    searchInput.dispatchEvent(new Event('change', { bubbles: true }));

    const norm = normCity(cityName);
    const REAL_TIMEOUT_MS = 20000; // реальные секунды по Date.now()
    const startTime = Date.now();

    // Один начальный yield: Ozon отвечает за ~300 мс, но даже если таймер
    // throttle-нут до 60 с — к моменту пробуждения результаты уже в DOM.
    await sleep(700);

    for (let attempt = 0; attempt < 8; attempt++) {
      // ── Сначала проверяем DOM, потом смотрим на дедлайн ────────────────
      // (Порядок важен: при throttle 60 с Date.now()-startTime > 20000 уже
      //  в первой итерации, но результаты есть → нашли до break'а.)

      // В таблице строк
      const rows = document.querySelectorAll('tr, [role="row"]');
      for (const row of rows) {
        if (!normCity(row.textContent).includes(norm)) continue;
        const checkbox = row.querySelector('input[type="checkbox"]');
        if (!checkbox) continue;
        if (checkbox.checked) return 'already';
        const label = checkbox.closest('label') || checkbox.parentElement;
        if (label) label.click(); else checkbox.click();
        await sleep(400);
        return 'checked';
      }

      // В popover/dropdown
      const popovers = document.querySelectorAll('[ods-popover-reference], [role="listbox"], [role="option"]');
      for (const p of popovers) {
        if (normCity(p.textContent).includes(norm)) {
          p.click();
          await sleep(600);
          break;
        }
      }

      // В span результатов
      const spans = document.querySelectorAll('.nd4-ak3 span, td span');
      for (const span of spans) {
        if (normCity(span.textContent.trim()) !== norm) continue;
        const parentRow = span.closest('tr') || span.closest('[role="row"]') || span.parentElement?.parentElement;
        if (!parentRow) continue;
        const cb = parentRow.querySelector('input[type="checkbox"]');
        if (!cb) continue;
        if (cb.checked) return 'already';
        const lbl = cb.closest('label') || cb.parentElement;
        if (lbl) lbl.click(); else cb.click();
        await sleep(400);
        return 'checked';
      }

      // ── Проверяем реальный дедлайн (после DOM-проверок) ─────────────────
      if (Date.now() - startTime > REAL_TIMEOUT_MS) break;

      // Ещё одна пауза перед следующей попыткой
      await sleep(600);
    }

    return 'not_found';
  }

  // Нормализация для сравнения: ё→е, нижний регистр, trim
  function normCity(s) {
    return (s || '').toLowerCase().replace(/ё/g, 'е').trim();
  }

  // Генерирует альтернативный вариант написания: заменяет е→ё или ё→е
  function altSpelling(s) {
    if (/ё/.test(s)) return s.replace(/ё/g, 'е');
    if (/е/.test(s)) return s.replace(/е/g, 'ё');
    return null;
  }

  // Обёртка: пробуем оригинальное написание, затем альтернативное е↔ё.
  // Без Promise.race — оба вызова последовательные, каждый со своим дедлайном.
  async function searchAndSelectCity(cityName) {
    const result = await _doSearchAndSelect(cityName);
    if (result === 'not_found') {
      const alt = altSpelling(cityName);
      if (alt && alt !== cityName) {
        log(`→ Пробуем альтернативное написание: «${alt}»`);
        return _doSearchAndSelect(alt);
      }
    }
    return result;
  }

  // ── Обработка одной зоны ────────────────────────────────────────────────

  async function processZone(warehouseName, zoneTitle, cities) {
    const report = { zone: zoneTitle, checked: [], already: [], notFound: [], failed: [] };

    log(`\n═══ ${zoneTitle} — ${cities.length} городов ═══`);

    // 1. Клик на карандаш
    if (!await findZoneEditButton(warehouseName, zoneTitle)) {
      log(`⚠️ Карандаш «${zoneTitle}» не найден — ещё раз expandHiddenMethods...`);
      await expandHiddenMethods(warehouseName);
      await sleep(1000);
      if (!await findZoneEditButton(warehouseName, zoneTitle)) {
        log(`❌ Не удалось открыть «${zoneTitle}» — зона пропускается`);
        return report;
      }
    }
    await sleep(1500);

    // 2. Далее → переход на страницу поиска
    await clickButton('Далее');
    if (!await waitForSearchPage()) {
      await sleep(3000);
      await clickButton('Далее');
      await waitForSearchPage();
    }

    // 3. Ищем и отмечаем города
    for (let i = 0; i < cities.length; i++) {
      checkStop();

      // Сигнал «Пропустить зону» — выходим из цикла городов и идём к сохранению
      if (window.__SD_SKIP_ZONE) {
        window.__SD_SKIP_ZONE = false;
        log(`⏭ Зона пропущена на городе ${i + 1}/${cities.length} — переходим к сохранению`);
        break;
      }

      // Активируем вкладку перед каждым городом — иначе Chrome throttle-ит таймеры в фоне
      window.dispatchEvent(new CustomEvent('sd-activate-tab'));
      await sleep(200);

      const city = cities[i];
      log(`→ [${i + 1}/${cities.length}] ${city}`);

      let status;
      try {
        status = await searchAndSelectCity(city);
      } catch (err) {
        log(`❌ [${i + 1}/${cities.length}] ${city} — исключение: ${err.message}`);
        report.failed.push(city);
        sendProgress(i + 1, cities.length, zoneTitle);
        continue;
      }

      switch (status) {
        case 'checked':
          log(`✅ [${i + 1}/${cities.length}] ${city} — отмечен`);
          report.checked.push(city);
          break;
        case 'already':
          log(`✓ [${i + 1}/${cities.length}] ${city} — уже отмечен`);
          report.already.push(city);
          break;
        case 'not_found':
          log(`⚠️ [${i + 1}/${cities.length}] ${city} — не найден`);
          report.notFound.push(city);
          break;
        case 'timeout':
          log(`⏱ [${i + 1}/${cities.length}] ${city} — таймаут поиска (пропущен)`);
          report.notFound.push(city);
          break;
        default:
          log(`❌ [${i + 1}/${cities.length}] ${city} — ошибка (${status})`);
          report.failed.push(city);
      }

      sendProgress(i + 1, cities.length, zoneTitle);
    }

    // 4. Сохранение: кликаем Далее до появления Сохранить (до 8 шагов)
    log('→ Сохраняем зону...');
    let saved = false;
    for (let step = 0; step < 8; step++) {
      // Сначала проверяем Сохранить
      const allBtns = [...document.querySelectorAll('button')];
      const saveBtn = allBtns.find(b => b.textContent.trim() === 'Сохранить' && b.offsetParent !== null && !b.disabled);
      if (saveBtn) {
        saveBtn.scrollIntoView({ block: 'center' });
        await sleep(300);
        saveBtn.click();
        log(`→ Клик «Сохранить» (шаг ${step + 1})`);
        saved = true;
        break;
      }
      // Иначе — Далее
      const next = await clickButton('Далее', 3000);
      if (!next) {
        log(`⚠️ Шаг ${step + 1}: ни «Сохранить» ни «Далее» не найдены`);
        break;
      }
      await sleep(1200);
    }
    if (!saved) log('⚠️ Кнопка «Сохранить» не найдена — зона возможно не сохранена');

    // Ждём закрытия редактора: поле поиска городов исчезает
    log('→ Ожидаем закрытия редактора зоны...');
    for (let i = 0; i < 20; i++) {
      const inp = document.querySelector("input[placeholder='Направление доставки']");
      if (!inp || inp.offsetParent === null) {
        log(`→ Редактор закрыт (${i + 1}с)`);
        break;
      }
      await sleep(1000);
    }
    await sleep(1500); // доп. пауза на анимацию закрытия

    // Отчёт
    log(`═══ Отчёт: ${zoneTitle} ═══`);
    log(`→ Отмечено: ${report.checked.length}, уже были: ${report.already.length}, не найдено: ${report.notFound.length}`);

    return report;
  }

  // ── Маппинг зон Excel → страница ───────────────────────────────────────

  function matchZones(pageZones, excelZones) {
    const mapping = {};
    for (const excelZone of Object.keys(excelZones)) {
      const zoneMatch = excelZone.match(/(\d+)/);
      const zoneNum = zoneMatch ? zoneMatch[1] : '';

      for (const pz of pageZones) {
        if (Object.values(mapping).includes(pz.title)) continue;
        if (excelZone.toLowerCase() === pz.title.toLowerCase()) {
          mapping[excelZone] = pz.title;
          break;
        }
        if (zoneNum) {
          const pattern = new RegExp(`зона\\s*\\.?\\s*${zoneNum}(?!\\d)`, 'i');
          if (pattern.test(pz.title)) {
            mapping[excelZone] = pz.title;
            break;
          }
        }
      }
    }
    return mapping;
  }

  // ── MAIN ────────────────────────────────────────────────────────────────

  async function main() {
    log('🚀 Озон Склады — старт автоматизации');

    const raw = document.documentElement.dataset.sdTaskParams;
    let taskData = null;
    if (raw) {
      delete document.documentElement.dataset.sdTaskParams;
      try { taskData = JSON.parse(raw); } catch {}
    }
    if (!taskData) {
      log('❌ Параметры задачи не найдены');
      setStatus('error', 'No task params');
      return;
    }
    const params = taskData.params || {};
    const cities = params.cities || [];

    if (!cities.length) {
      log('❌ Список городов пуст');
      setStatus('error', 'Empty cities');
      return;
    }

    log(`→ Городов: ${cities.length}`);

    // Проверка авторизации
    if (!await checkAuth()) {
      log('⚠️ Требуется авторизация. Войдите в аккаунт Ozon Seller.');
      log('→ Ожидание авторизации...');
      for (let i = 0; i < 120; i++) {
        await sleep(2000);
        if (await checkAuth(5000)) break;
      }
      if (!await checkAuth(5000)) {
        log('❌ Авторизация не выполнена');
        setStatus('error', 'Auth failed');
        return;
      }
    }
    log('✅ Авторизация подтверждена');

    // Прокручиваем страницу чтобы подгрузить все склады (lazy loading)
    await scrollToLoadAllWarehouses();

    // Сканируем склады
    let warehouses = scanWarehouses();
    if (!warehouses.length) {
      log('❌ Склады не найдены');
      setStatus('error', 'No warehouses');
      return;
    }

    log(`→ Найдено складов: ${warehouses.length}`);
    for (const wh of warehouses) {
      log(`   • ${wh.name} (${wh.zones.length} зон)`);
    }

    // Выбираем склад по имени из параметров (пользователь выбрал в UI)
    const warehouseName = params.ozonWarehouseName || warehouses[0].name;

    // Поиск склада: точное совпадение → нормализованное (только точки→пробел, регистр, ё→е)
    // Скобки НЕ убираем — «Склад (старый)» и «Склад» должны различаться
    function normWh(s) {
      return (s || '').toLowerCase().replace(/ё/g, 'е').replace(/\./g, ' ').replace(/\s+/g, ' ').trim();
    }
    const targetNorm = normWh(warehouseName);
    const warehouse =
      warehouses.find(w => w.name === warehouseName) ||
      warehouses.find(w => normWh(w.name) === targetNorm);

    if (!warehouse) {
      log(`❌ Склад «${warehouseName}» не найден на странице`);
      setStatus('error', 'Warehouse not found');
      return;
    }
    const resolvedName = warehouse.name;
    if (resolvedName !== warehouseName) {
      log(`→ Склад найден по частичному совпадению: «${resolvedName}»`);
    } else {
      log(`→ Выбран склад: ${resolvedName}`);
    }

    // Раскрываем скрытые методы
    await expandHiddenMethods(resolvedName);
    await sleep(1000);

    // Пересканируем
    warehouses = scanWarehouses();
    const updatedWh =
      warehouses.find(w => w.name === resolvedName) ||
      warehouses.find(w => normWh(w.name) === normWh(resolvedName));
    if (!updatedWh) {
      log('❌ Склад не найден после обновления');
      setStatus('error', 'Warehouse lost');
      return;
    }

    const pageZones = updatedWh.zones;
    log(`→ Зон на странице: ${pageZones.length}`);

    // Строим citiesData: маппинг pageZoneTitle → список городов
    // params.ozonPageZones — выбранные пользователем зоны (titles со страницы)
    // params.zones — данные из Excel: { "Зона 1": ["Москва","Пенза",...], "Зона 2": [...] }
    let citiesData = {};
    const selectedPageZones = params.ozonPageZones || [];
    const excelZones = params.zones || {};
    const excelKeys = Object.keys(excelZones);

    if (selectedPageZones.length > 0 && excelKeys.length > 0) {
      // Маппим по порядковому номеру зоны: "Зона 1" из Excel → первая выбранная page zone
      for (const excelKey of excelKeys) {
        const zoneMatch = excelKey.match(/(\d+)/);
        const zoneNum = zoneMatch ? parseInt(zoneMatch[1]) : 0;
        // Ищем page zone с тем же номером
        let matched = false;
        for (const pzTitle of selectedPageZones) {
          const pageMatch = pzTitle.match(/(\d+)/);
          const pageNum = pageMatch ? parseInt(pageMatch[1]) : 0;
          if (zoneNum > 0 && zoneNum === pageNum) {
            citiesData[pzTitle] = excelZones[excelKey];
            matched = true;
            break;
          }
        }
        if (!matched && selectedPageZones.length === 1) {
          citiesData[selectedPageZones[0]] = excelZones[excelKey];
        }
      }
    } else if (selectedPageZones.length > 0) {
      // Нет Excel данных — все города в каждую выбранную зону
      for (const pzTitle of selectedPageZones) {
        citiesData[pzTitle] = cities;
      }
    } else if (excelKeys.length > 0) {
      // Нет выбранных page zones — используем matchZones как fallback
      const zoneMapping = matchZones(pageZones, excelZones);
      for (const [ek, pt] of Object.entries(zoneMapping)) {
        citiesData[pt] = excelZones[ek];
      }
    } else {
      if (pageZones.length > 0) {
        citiesData[pageZones[0].title] = cities;
      }
    }

    log('→ Зоны для обработки:');
    for (const [zone, zoneCities] of Object.entries(citiesData)) {
      log(`   ${zone} — ${zoneCities.length} городов`);
    }

    if (!Object.keys(citiesData).length) {
      log('❌ Ни одна зона не сопоставлена');
      setStatus('error', 'No zone mapping');
      return;
    }

    // Обрабатываем каждую зону
    const allReports = [];
    for (const [pageZoneTitle, zoneCities] of Object.entries(citiesData)) {
      checkStop();
      if (!zoneCities.length) continue;

      const report = await processZone(resolvedName, pageZoneTitle, zoneCities);
      allReports.push(report);

      // Редактор закрыт. После сохранения Ozon сбрасывает lazy-load —
      // список складов снова показывает только первые ~5. Прокручиваем заново.
      await sleep(3000); // пауза: даём странице полностью осесть после сохранения
      await scrollToLoadAllWarehouses();

      // Проверяем что наш склад виден; если нет — одна повторная попытка
      let cardsAfter = [...document.querySelectorAll('[data-widget="warehouse-card-title"]')];
      let targetCard = cardsAfter.find(c => normWh(c.textContent.trim()) === normWh(resolvedName));
      if (!targetCard) {
        log('→ Склад не найден с первой прокрутки — повторная попытка...');
        await sleep(3000);
        await scrollToLoadAllWarehouses();
        cardsAfter = [...document.querySelectorAll('[data-widget="warehouse-card-title"]')];
        targetCard = cardsAfter.find(c => normWh(c.textContent.trim()) === normWh(resolvedName));
      }
      if (!targetCard) {
        log(`⚠️ Склад «${resolvedName}» не найден после прокрутки — пропускаем остаток`);
        break;
      }

      // Раскрываем методы (могли свернуться после сохранения)
      log('→ Проверяем раскрытие зон...');
      await expandHiddenMethods(resolvedName);
      await sleep(800);
    }

    // Итоговый отчёт
    const totalChecked = allReports.reduce((s, r) => s + r.checked.length, 0);
    const totalAlready = allReports.reduce((s, r) => s + r.already.length, 0);
    const totalNotFound = allReports.reduce((s, r) => s + r.notFound.length, 0);

    log(`\n═══ ИТОГО ═══`);
    log(`→ Зон обработано: ${allReports.length}`);
    log(`✅ Отмечено: ${totalChecked}`);
    log(`✓ Уже были: ${totalAlready}`);
    log(`⚠️ Не найдено: ${totalNotFound}`);

    setStatus('completed', `Отмечено ${totalChecked}, не найдено ${totalNotFound}`);
    log('🏁 Готово!');
  }

  setTimeout(() => {
    main().catch(err => {
      if (err.message === 'STOPPED') {
        log('⏹ Остановлено');
        setStatus('stopped');
      } else {
        log(`❌ Ошибка: ${err.message}`);
        setStatus('error', err.message);
      }
    });
  }, 1000);
})();
